#!/system/bin/sh
if ! applypatch -c MTD:recovery:5756928:a34785dfb8f36f668029f6a902897ebd0e4f1422; then
  applypatch  MTD:boot:5756928:a34785dfb8f36f668029f6a902897ebd0e4f1422 MTD:recovery a34785dfb8f36f668029f6a902897ebd0e4f1422 5756928 a34785dfb8f36f668029f6a902897ebd0e4f1422:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi

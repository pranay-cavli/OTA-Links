#!/system/bin/sh
if ! applypatch -c MTD:recovery:5754880:93012ff692083f140d318750ce33e1f7efb400b2; then
  applypatch  MTD:boot:5754880:93012ff692083f140d318750ce33e1f7efb400b2 MTD:recovery 93012ff692083f140d318750ce33e1f7efb400b2 5754880 93012ff692083f140d318750ce33e1f7efb400b2:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi

#!/system/bin/sh
if ! applypatch -c MTD:recovery:5801984:ff95d468f6166f17277b0f0a681fdb296d365b3d; then
  applypatch  MTD:boot:5801984:ff95d468f6166f17277b0f0a681fdb296d365b3d MTD:recovery ff95d468f6166f17277b0f0a681fdb296d365b3d 5801984 ff95d468f6166f17277b0f0a681fdb296d365b3d:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
